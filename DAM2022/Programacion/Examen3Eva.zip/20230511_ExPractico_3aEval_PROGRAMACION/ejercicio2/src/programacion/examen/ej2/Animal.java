package programacion.examen.ej2;

public abstract class Animal {
  // nombre;
  // edad;
  // peso;
  TipoAnimal tipo;

  public Animal(String nombre, int edad, float peso, TipoAnimal tipo) {
    // TODO
  }

  public TipoAnimal getTipo() {
    return tipo;
  }

  @Override
  public String toString() {
    // TODO: Devuelve una cadena que represente los detalles del animal. El formato
    // sería "<tipo>: <nombre>, <edad> años, 'String.format("%.2f", peso)' kilos"
  }
}
