package programacion.examen.ej3;

public class ApuestaEuromillonesException extends /* tipo Excepción unchecked/no comprobada */ {
  // TODO
}
