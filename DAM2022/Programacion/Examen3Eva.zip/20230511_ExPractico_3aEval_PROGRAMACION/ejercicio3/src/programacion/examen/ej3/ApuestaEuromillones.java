package programacion.examen.ej3;

public class ApuestaEuromillones {
  // TODO: declara las colecciones apropiadas para numeros y estrellas:
  // TipoColeccion numeros;
  // TipoColeccion estrellas;


  @Override
  public String toString() {
    String cadena = "";

    // TODO

    return cadena;
  }

}
