import programacion.examen.ej1.ContadorLetra;
import programacion.examen.ej1.ContadorPalabra;

public class MainEjercicio1 {

  public static void main(String[] args) {
    
    contarPalabras(args[0]);
    
    contarLetras(args[0]);

  }

  private static void contarLetras(String rutaFichero) {
    
  }

  private static void contarPalabras(String rutaFichero) {

  }
}