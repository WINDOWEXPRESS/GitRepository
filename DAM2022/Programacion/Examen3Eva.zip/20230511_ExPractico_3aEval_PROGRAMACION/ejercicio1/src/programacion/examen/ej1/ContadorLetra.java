package programacion.examen.ej1;

public class ContadorLetra implements Comparable<ContadorLetra> {
  Character letra;
  Integer contador;

  public ContadorLetra(Character letra, int contador) {
    //TODO
  }

  public Character getLetra() {
    //TODO
  }

  public Integer getContador() {
    //TODO
  }

}
