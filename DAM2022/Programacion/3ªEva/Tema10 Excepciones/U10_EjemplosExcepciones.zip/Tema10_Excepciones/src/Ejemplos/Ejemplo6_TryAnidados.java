package Ejemplos;

public class Ejemplo6_TryAnidados {

	public static void main(String[] args) {
		int numerador[] = {4,8,16,32,64,128,256,512};
		int denominador[] = {2,0,4,4,0,8};
		int num_exc=0
	   try {
		   for(int i=0; i<numerador.length; i++){
			   try {
				   System.out.println(numerador[i]+"/"+denominador[i]
				   +" = "+numerador[i]/denominador[i]);
			   }
			   catch (ArithmeticException exc){
				   num_exc++;
				   System.out.println("\n\n\nEXCEPCION :"+num_exc);
				   System.out.println("----------- :");
				   System.out.println("Mi mensaje de la excepci�n");
				   System.out.println("No puede dividir por 0");
                   System.out.println("\nMensaje con el el objeto directamente");				   
				   System.out.println(exc); // mensaje estandar equivale a exc.toString()
				   System.out.println("\nMensaje con el Nombre de la excepci�n con toString() :");
				   System.out.println(exc.toString());
				   System.out.println("\nDescripcion de la excepcion con getMessage :");
				   System.out.println("Descripcion de la excepcion :"+exc.getMessage());
				   System.out.println("\nTrazabilidad de la excepci�n con printStackTrace :");
				   exc.printStackTrace();
				   
			   } 
			   
			}
	   }
	   catch (ArrayIndexOutOfBoundsException exc){
		   System.out.println("Elemento no encontrado en vector denominador");
		   System.out.println("PROGRAMA TERMINADO");
	   }

	}

}
