package Ejemplo4_ClasesAbstract;

public class UsoClaseAbstracta {

	public static void main(String[] args) {
		ClaseAbstracta1 objAbs1 = new Derivada("Pedro");
		
		objAbs1.saludo();
		
		objAbs1.saludar();

	}

}
