package Ejemplo4_ClasesAbstract;

public abstract class ClaseAbstracta1 {
	
	String nombrePersona;
	
	public void saludo () {
		System.out.println("Hola Mundo");
	}
	
	public abstract void saludar();

}
