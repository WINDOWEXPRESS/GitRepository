package Ejemplo6_Enumerados;

public class UsoEnumerados {
	
	public static void main(String[] args) {
		Talla t=Talla.PEQUE�A;
		Demarcacion puesto= Demarcacion.DEFENSA;
		Demarcacion puesto2=Demarcacion.PORTERO;
		
		System.out.println("Qu� visualiza el m�todo toString(): "+t.toString());
		System.out.println("Qu� visualiza el m�todo ordinal(): "+t.ordinal());
		System.out.println("Qu� visualiza el m�todo comparteTo(): "+puesto2.compareTo(puesto));
	}

	
	public enum Talla{PEQUE�A,MEDIANA,GRANDE};
			
	public enum Demarcacion{PORTERO, DEFENSA, DELANTERO, CENTROCAMPISTA};
}
