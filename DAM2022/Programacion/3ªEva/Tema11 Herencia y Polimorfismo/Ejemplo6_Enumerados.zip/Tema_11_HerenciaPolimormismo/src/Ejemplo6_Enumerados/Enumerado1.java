package Ejemplo6_Enumerados;

public enum Enumerado1 {

}
