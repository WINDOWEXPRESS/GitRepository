package programacion.examen.ej2;

public enum TipoAnimal {

    AVE(), MAMIFERO();

}
