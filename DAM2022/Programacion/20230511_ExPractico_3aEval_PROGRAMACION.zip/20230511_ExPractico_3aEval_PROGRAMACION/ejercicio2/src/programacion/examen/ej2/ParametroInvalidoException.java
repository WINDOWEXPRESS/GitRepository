package programacion.examen.ej2;

public class ParametroInvalidoException extends Exception{
    public ParametroInvalidoException(){

    }
    public ParametroInvalidoException(String msg){
        super(msg);
    }
}
