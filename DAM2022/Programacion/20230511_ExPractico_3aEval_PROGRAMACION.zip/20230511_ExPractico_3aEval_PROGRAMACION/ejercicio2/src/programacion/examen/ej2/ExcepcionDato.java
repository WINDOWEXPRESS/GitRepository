package programacion.examen.ej2;

public class ExcepcionDato extends Exception{
    public ExcepcionDato(){

    }
    public ExcepcionDato(String msg){
        super(msg);
    }
}
