package programacion.examen.ej3;

public class ApuestaEuromillonesException extends RuntimeException {
  public ApuestaEuromillonesException() {

  }

  public ApuestaEuromillonesException(String msg) {
    super(msg);
  }
}
