package programacion.examen.ej1;

import java.util.TreeMap;

public class ContadorPalabra {
    TreeMap<Character,Integer> coleccionPalabras = null;
    public ContadorPalabra(String[] listaPalabras){
        coleccionPalabras = new TreeMap<>();
        
    }
}
