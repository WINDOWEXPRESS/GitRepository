-- EXPLICACION EJERCICIO 7 JARDINERIA

-- 7.- Igual que el anterior, pero mostrando las oficinas que no tienen empleados.
-- CORRECTA
select oficinas.codigooficina, ciudad, empleados.codigoempleado, empleados.nombre
from oficinas LEFT JOIN empleados ON oficinas.codigooficina=empleados.codigooficina 
and oficinas.region='EMEA';

-- REVISAR - ERROR: el resultado es erroneo porque no devuelve las oficinas que no tienen
-- empleados (a null). Realmente la consulta está correctamente planteada aunque el resultado 
-- no es el que esperamos. Explicación en documento adicional.
select oficinas.codigooficina, oficinas.ciudad, empleados.codigoempleado, empleados.nombre
from oficinas, empleados
where oficinas.codigooficina(+)=empleados.codigooficina 
and oficinas.region='EMEA';

-- La explicación es simple pero se puede olvidar en un momento dado, como me pasó a mí, 
-- la detallo a continuación, pero lo mejor siempre es contrastar con la documentación 
-- oficial del SGBD que estemos utilizando (Oracle DB).

-- Como hemos visto en el tema de JOIN, hay dos formas de realizar este tipo de consultas:
-- Una utilizando el operador (+) y la otra utilizando la clausula JOIN, LEFT JOIN, ...

-- En el caso de utilizar el operador (+), como se implementó en las primeras versiones 
-- del estandar de SQL, no incluye la funcionalidad de mostrar los valores nulos a la hora de 
-- realizar un LEFT JOIN, como es el ejemplo que nos ocupa, 
-- por eso para obtener este tipo de consultas 
-- se recomienda utilizar las clausulas LEFT JOIN, RIGHT JOIN, ... mejor que el operador (+). 

-- En el siguiente enlace, se explica en detalle los diferentes tipos de JOIN 
-- https://docs.oracle.com/cd/B28359_01/server.111/b28286/queries006.htm#SQLRF52336
-- y en uno de sus apartados, podéis comprobar que se recomienda usar 
-- las clausulas LEFT JOIN, RIGHT JOIN, ... mejor que el operador(+), además de otras 
-- consideraciones como:

-- A WHERE condition containing the (+) operator cannot be combined with another condition using 
-- the OR logical operator.

-- A WHERE condition cannot use the IN comparison condition to compare a column marked with 
-- the (+) operator with an expression.

/*
Oracle recommends that you use the FROM clause OUTER JOIN syntax rather than the Oracle join 
operator. Outer join queries that use the Oracle join operator (+) are subject to the following 
rules and restrictions, which do not apply to the FROM clause OUTER JOIN syntax:

You cannot specify the (+) operator in a query block that also contains FROM clause join syntax.

The (+) operator can appear only in the WHERE clause or, in the context of left-correlation 
(when specifying the TABLE clause) in the FROM clause, and can be applied only to a column 
of a table or view.

If A and B are joined by multiple join conditions, then you must use the (+) operator in all 
of these conditions. If you do not, then Oracle Database will return only the rows resulting 
from a simple join, but without a warning or error to advise you that you do not have the results 
of an outer join.

The (+) operator does not produce an outer join if you specify one table in the outer query and 
the other table in an inner query.

You cannot use the (+) operator to outer-join a table to itself, although self joins are valid. 
For example, the following statement is not valid:

-- The following statement is not valid:
SELECT employee_id, manager_id 
   FROM employees
   WHERE employees.manager_id(+) = employees.employee_id;

-- However, the following self join is valid:
SELECT e1.employee_id, e1.manager_id, e2.employee_id
   FROM employees e1, employees e2
   WHERE e1.manager_id(+) = e2.employee_id
   ORDER BY e1.employee_id, e1.manager_id, e2.employee_id;

The (+) operator can be applied only to a column, not to an arbitrary expression. However, 
an arbitrary expression can contain one or more columns marked with the (+) operator.

A WHERE condition containing the (+) operator cannot be combined with another condition using 
the OR logical operator.

A WHERE condition cannot use the IN comparison condition to compare a column marked with 
the (+) operator with an expression.

If the WHERE clause contains a condition that compares a column from table B with a constant, 
then the (+) operator must be applied to the column so that Oracle returns the rows from 
table A for which it has generated nulls for this column. Otherwise Oracle returns only 
the results of a simple join.

In a query that performs outer joins of more than two pairs of tables, a single table can be 
the null-generated table for only one other table. For this reason, you cannot apply the (+) 
operator to columns of B in the join condition for A and B and the join condition for B and C. Refer to SELECT for the syntax for an outer join.
*/
